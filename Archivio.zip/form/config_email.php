<?php
	//Creato da Mel Riccardo
	//v 2.0
	//http://www.targetweb.it 
	//riky.mel@gmail.com
	//Vietata ogni tipo di riproduzione, distribuzione senza previa richiesta al programmatore
	//file di configurazione variabili
	
	$tua_email = "simer.srls@gmail.com";
	
	$sito_internet	=	"Simer Srls";
	
	$grazie = "http://www.simer.srls.it";

?>